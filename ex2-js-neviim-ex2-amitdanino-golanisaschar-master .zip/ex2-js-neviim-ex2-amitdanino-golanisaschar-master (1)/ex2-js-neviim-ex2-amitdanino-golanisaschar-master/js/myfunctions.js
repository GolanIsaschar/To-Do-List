localStorage.clear();

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("add").addEventListener("click", saveTask);
    document.getElementById("sort").addEventListener("click", sortTasks);
    document.getElementById("ShowHighPriority").addEventListener("click", highPriority);
    document.getElementById("back").addEventListener("click", noHighPriority);
    document.getElementById("title").addEventListener("input", deleteErrorMsg);
});

//add the new task to the to do list
function saveTask(e){

    deleteErrorMsg();
    let title = document.getElementById('title').value.trim();
    let description = document.getElementById('description').value.trim();
    let priority = document.getElementById("scales").checked;

    let task = {
        title ,
        description,
        priority,
    };
    if (!validator(title , description)) {
        return;
    }

    if(localStorage.getItem('tasks') == null){
        let tasks = [];
        tasks.push(task);
        localStorage.setItem('tasks' , JSON.stringify(tasks));
    }
    else{
        let tasks = JSON.parse(localStorage.getItem('tasks'));
        tasks.push(task);
        localStorage.setItem('tasks' ,JSON.stringify(tasks));
    }
    getTasks(false);

    document.getElementById('form-Task').reset();
    e.preventDefault();
}

//delete task from the to do list
function deleteTask(title){
    let tasks = JSON.parse(localStorage.getItem('tasks'));
    for (let i = 0 ; i < tasks.length; i++){
        if (tasks[i].title === title){
            tasks.splice(i,1);
        }
    }
    localStorage.setItem('tasks' ,JSON.stringify(tasks));
    deleteErrorMsg();
    getTasks(false);
}

//show the to do list on the website
function getTasks(prior){


    let tasks = JSON.parse(localStorage.getItem('tasks'));
    let tasksView = document.getElementById('tasks');
    if(tasksView !== null) {
        tasksView.innerHTML = "";

        for (let i = 0; i < tasks.length; i++) {

            let title = tasks[i].title;
            let description = tasks[i].description;

            if (prior) {
                if (tasks[i].priority)
                    tasksView.innerHTML += regularPrint(title, description);
            } else {
                if (tasks[i].priority)
                    tasksView.innerHTML += priorityPrint(title, description);
                else
                    tasksView.innerHTML += regularPrint(title, description);
            }
        }
    }
}

//sort the to do list
function sortTasks(){
    let tasks = JSON.parse(localStorage.getItem('tasks'));
    tasks.sort(compare);
    localStorage.setItem('tasks' ,JSON.stringify(tasks));
    getTasks(false);
}

//the sort function is using this function
function compare(a, b) {
    return a.title.toString().localeCompare(b.title.toString());
}

//show only the high priority tasks
function highPriority(){

    document.getElementById("hide").classList.add("d-none");
    document.getElementById("back").classList.remove("d-none");
    document.getElementById("ShowHighPriority").classList.add("d-none");
    document.getElementById("add").classList.add("d-none");
    document.getElementById("sort").classList.add("d-none");
    getTasks(true);
}

//return to the regular to do list
function noHighPriority(){

    document.getElementById("hide").classList.remove("d-none");
    document.getElementById("back").classList.add("d-none");
    document.getElementById("ShowHighPriority").classList.remove("d-none");
    document.getElementById("add").classList.remove("d-none");
    document.getElementById("sort").classList.remove("d-none");
    getTasks(false);
}

//print task that is not prioritize
function regularPrint(title , description){

    return (`<div class = "card mb-3">
                <div class = "card-body">
                    <div class = "row">
                        <div class = "col-sm-3 text-left">
                                <p>${title}</p>
                        </div>
                        <div class = "col-sm-7 text-left">
                                <p>${description}</p>
                        </div>
                         <div class = "col-sm-2 text-right">
                                <a href="#" onclick="deleteTask('${title}')" class = "btn btn-danger ml-5">X</a>
                        </div>
                    </div>
                </div> 
            </div>`);
}

//print task that is is prioritize
function priorityPrint(title , description){

    return (`<div class = "card mb-3">
                <div class = "card-body text-white bg-secondary">
                    <div class = "row">
                        <div class = "col-sm-3 text-left">
                                <p>${title}</p>
                        </div>
                        <div class = "col-sm-7 text-left">
                                <p>${description}</p>
                        </div>
                         <div class = "col-sm-2 text-right">
                                <a href="#" onclick="deleteTask('${title}')" class = "btn btn-danger ml-5">X</a>
                        </div>
                    </div>
                </div> 
            </div>`);
}

//task validator
function validator(title , description) {

    let tasksView = document.getElementById('errors');

    if(title === ""){
        tasksView.innerHTML += "please enter non-empty title";
        return false;
    }
    if(description === ""){
        tasksView.innerHTML += "please enter non-empty description";
        return false;
    }
    if(localStorage.getItem('tasks') == null)
        return true;

    let tasks = JSON.parse(localStorage.getItem('tasks'));
    if(tasks.find(x => x.title === title) !== undefined){
        let tasksView = document.getElementById('errors');
        tasksView.innerHTML += "please enter non-exist title";
        return false;
    }
    return true;
}

//delete the error massage when the user is typing task, adding task or deleting task
function deleteErrorMsg() {

    let tasksView = document.getElementById('errors');
    tasksView.innerHTML = '';
}

getTasks(false);